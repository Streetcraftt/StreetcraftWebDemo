add(2, 8);
function add(num1, num2){
    console.log(num1+num2);
}